# Main Harness desktop language pack

A real local DSH bundle for **main Harness chat and settings**, not an Ocean shell replacement. Languages are registered in this order: Русский (`ru`), Español (`es`), Português (Brasil) (`pt-BR`), Deutsch (`de`), Français (`fr`), 日本語 (`ja`), 한국어 (`ko`). Select a language with the existing **Settings → General → Language** control. The bundle never selects one on your behalf.

## Compatibility and scope

Tested target: npm-installed `@deepseek-ai/dsh` **0.2.0-rc.2**, `@deepseek-ai/dsh-client-locale` **0.2.0-rc.2**, Cordis **4.0.4**. Exact locale peer and `engines.dsh` record this target; engines are informational and do not replace the runtime's peer checks. There are no installed dependencies, install/prepare hooks, model tools, network calls, DOM replacements, monkeypatches, or private copies of React/Cordis.

Canonical English dictionaries were extracted from this runtime's compiled official client artifacts, not reconstructed from screenshots. Package versions, artifact SHA-256 hashes, variable names and key counts are recorded in `data/inventory.json`. Upstream English catalogs and derived translations retain the DeepSeek MIT notice in `LICENSE`.

| Namespace | Keys | Surface |
| --- | ---: | --- |
| `common` | 41 | Shared controls, code/JSON copying, Markdown labels |
| `settings.locale` | 1 | Existing Language row |
| `settings` | 34 | Settings shell, General, desktop update copy |
| `chat` | 186 | Main transcript, history, work details and usage |
| `conversation` | 369 | Composer, attachments, session/goal/todo detail UI |
| `workspace` | 112 | Workspace/session navigation and management |
| `model` | 23 | Model selector |
| `settings.models` | 113 | Model configuration and credential dialogs |
| `settings.plugins` | 5 | Plugins section |
| `settings.pluginInventory` | 40 | Plugin inventory |
| `pluginManager` | 189 | Official plugin manager UI |
| **Each language** | **1,113** | **11 complete dictionaries** |

All dictionary entries in this scope are included for every language; placeholders retain their exact names and multiplicity. These catalogs use plain strings with `{name}` substitution: there are no function values or ICU plural programs to convert. Existing `.one`/`.other` keys and caller behavior are retained. Technical literals (protocol names, URLs, command identifiers, units, punctuation, format-only templates), and words whose spelling is legitimately shared, can remain identical to English; `data/unchanged.json` records them for explicit audit, not hidden fallback.

### Deliberate remaining gaps

- Other official feature namespaces are **not included**: sidebar/browser/files/terminal, appearance/font settings, permission-mode settings, keyboard shortcuts, agent presets, approval-specific UI, account/sign-in, shell/search/subagent settings, schedules, workflow and experimental voice/team features. Consequently visible controls such as **New Session**, **Standard mode**, **Appearance**, **Permission**, **Font size**, **Keyboard shortcuts** and **Agent presets** can still be English; this is a scoped first language-pack release, not complete product localization. A `common` fallback can translate shared labels but is not a promise to translate those features.
- Native Ocean menus, setup/recovery screens and its own shell strings are outside this package. The previous shell localization worktree is independent and unchanged.
- A language pack can only supply registered namespace keys. Hardcoded English/Chinese strings, raw Host errors, schema/package metadata not routed through those dictionaries, and other plugins' own labels are not rewritten. Installed package titles/descriptions use separate `LocalizedText` metadata, not namespace lookup; third-party plugin localization is not promised.
- User/assistant messages, prompts, command names and arguments, paths, model/provider IDs, and tool result data are never translated or mutated. Some dictionary entries describe these items; only their surrounding UI copy is translated.
- Text captured once in an official registry (for example a command description registered at activation) may keep its previous language until that official component re-registers or the page reloads. Ordinary slot-rendered labels update immediately.
- The runtime owns browser-language matching, locale persistence and `<html lang>`. The pack does not add locale-dependent plural-selection logic, number/date formatting engines, fonts or bidirectional layout.
- Missing/new keys after a runtime upgrade fall back to English through the public API. Re-extract and review the inventory before widening the tested version. Other packs cannot own the same language id or `(namespace, language)` registration simultaneously; disable the conflicting pack first.

## Build and test (maintainers)

Run from this directory, with Node.js 22+ and npm:

```sh
npm test
npm run build
npm pack --ignore-scripts --pack-destination artifacts
npm run verify:fixture
```

No dependency install is needed. Source: `src/register.mjs`; maintained catalogs: `data/<language>.json`; tests: `test/*.test.mjs`; generated runtime artifacts: `lib/index.js` and `lib/client.js`. The browser build uses the installed official decoration template's `window.__ModuleLoader__.load({id, factory})` convention. `dsh.client.inject` names the locale package; plugin `inject: ['locale']` names its service. Every language and namespace disposer is owned by `ctx.effect`, so unloading removes registrations and permits re-enabling.

`npm test` covers full key/type/placeholder parity, translation coverage, language order, reversible effects, manifest/script safety, the actual installed `LocaleRuntime`, lazy module loading, and fixture isolation fences. During sequential translation development, `LANGUAGES=ru,es npm test` checks only completed catalogs plus the entire infrastructure suite. The unfiltered default checks all seven.

`npm run extract -- /absolute/npm/runtime/prefix` refreshes the canonical English snapshot and provenance from an installed runtime. This is an explicit maintainer action and does **not** auto-translate newly added keys. English extraction evaluates only the isolated known dictionary literal, never an entire upstream plugin.

### Isolated packed-tarball verification

`npm run verify:fixture` requires built artifacts, the installed runtime, `pnpm` on PATH and `/usr/bin/chromium` (override with `CHROMIUM`). Override the read-only runtime prefix using `DSH_INSTALL`. It creates a fresh private HOME/DSH_HOME/profile/cache tree under `artifacts/language-pack-fixture-*`, packs the real tarball, installs through the real `dsh plugin ... add` flow with scripts disabled, checks `--dump-config`, and starts that fixture with `--host 127.0.0.1 --port 0 --no-open`. It never uses `~/.dsh/profiles/web`, the running 3080 service, or the user's browser profile.

The verifier checks the real HTTP boot graph and served client bytes, uses its own headless Chromium profile to select all seven languages through the existing settings UI, captures screenshots, checks `<html lang>` and translated settings copy, reloads to check persistence, and stops its owned process groups. Results: `artifacts/fixture-result.json` and per-fixture logs/screenshots. The temporary profile persists only as evidence; it is excluded from the distributable. This is not installation into your live profile and does not update the current GUI.

## Live installation is intentionally not performed

The local tarball is the handoff artifact. No publication, live-profile installation, commit, merge or service replacement is part of this change. If separately authorized later, the official installation form is:

```sh
dsh plugin --profile <intended-profile> add /absolute/path/to/dsh-ocean-desktop-language-pack-0.1.0.tgz --ignore-scripts
```

A deliberate browser refresh may be required after installing the new client module. Uninstall with the official plugin manager; owned registrations are disposed without modifying messages or existing built-in dictionaries.
